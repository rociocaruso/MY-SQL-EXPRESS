var mysql=require('mysql');

var conexion=mysql.createConnection({
    host:'remotemysql.com', 
   user:'iQkIXWi1VP', 
   password:'oWEqU5rNNO', 
   database:'iQkIXWi1VP' 
});

conexion.connect(function (error){
    if (error)
        console.log('Problemas de conexion con mysql');
    else
        console.log('se inicio conexion');
});


module.exports=conexion;