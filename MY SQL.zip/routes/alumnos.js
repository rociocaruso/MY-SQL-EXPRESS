var express = require('express');
var router = express.Router();

var bd=require('./bd');


//Alta de registros
router.get('/alta', function(req, res, next) {
  res.render('altaalumnos');
});


router.post('/alta', function(req, res, next) {
      var registro={
        leg_alumno:req.body.leg_alumno,
        apyn_alumno:req.body.apyn_alumno,
        dom_alumno:req.body.dom_alumno,
        cod_postal:req.body.cod_postal,
        fecha_nac_alumno:req.body.fecha_nac_alumno,
        email_alumno:req.body.email_alumno,
        grupo_sang_alumno:req.body.grupo_sang_alumno,
        tel_fijo_alumno:req.body.tel_fijo_alumno,
        tel_movil_alumno:req.body.tel_movil_alumno,
        dni_alumno:req.body.dni_alumno
      };
      bd.query('insert into alumnos set ?',registro, function (error,resultado){
          if (error){
              console.log(error);
              return;
          }
      });    
  res.render('mensajes',{mensaje:'La carga se efectuo correctamente'});
});


//Listado de registros
router.get('/listado', function(req, res, next) {
  bd.query('select * from alumnos', function(error,filas){
        if (error) {            
            console.log('error en el listado');
            return;
        }    
        res.render('listaralumnos',{alumnos:filas});
  });
});

//Consulta
router.get('/consulta', function(req, res, next) {
  res.render('consultaalumnos');
});

//Consulta Batan
router.get('/consultabtn', function(req, res, next) {
  bd.query('select * from alumnos where cod_postal= 7601', function(error,filas){
        if (error) {            
            console.log('error en el listado');
            return;
        }    
        res.render('batanconsulta',{alumnos:filas});
  });
});

//Consulta 2002
router.get('/nac02', function(req, res, next) {
  bd.query('select * from alumnos where fecha_nac_alumno like "%2002%"', function(error,filas){
        if (error) {            
            console.log('error en el listado');
            return;
        }    
        res.render('2002',{alumnos:filas});
  });
});

//Consulta Batan y RH-
router.get('/btn_rh', function(req, res, next) {
  bd.query('select * from alumnos where cod_postal=7601 and grupo_sang_alumno="RH-"', function(error,filas){
        if (error) {            
            console.log('error en el listado');
            return;
        }    
        res.render('btn-rh',{alumnos:filas});
  });
});

//Consulta DNI Asc
router.get('/asc', function(req, res, next) {
  bd.query('select * from alumnos order by dni_alumno asc', function(error,filas){
        if (error) {            
            console.log('error en el listado');
            return;
        }    
        res.render('DNI_Asc',{alumnos:filas});
  });
});

//Consulta Av Justo
router.get('/av', function(req, res, next) {
  bd.query('select * from alumnos where dom_alumno="AV. J.B. Justo"', function(error,filas){
        if (error) {            
            console.log('error en el listado');
            return;
        }    
        res.render('avenida',{alumnos:filas});
  });
});

module.exports = router;
